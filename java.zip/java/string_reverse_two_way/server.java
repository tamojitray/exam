//regular string reverse
import java.io.*;
import java.net.*;

class server 
{
    public static void main(String args[]) throws Exception
    {
        ServerSocket ss = new ServerSocket(888);
        Socket s = ss.accept();
        System.out.println("Connection established");
        PrintStream ps= new PrintStream(s.getOutputStream());
        BufferedReader br= new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedReader kb= new BufferedReader(new InputStreamReader(System.in));
        while (true) 
        {
            String str, str1;
            while ((str = br.readLine()) != null) 
            {
                String rev="";
                for(int i = str.length() - 1; i >= 0; i--)
                {
                    rev = rev + str.charAt(i);
                }
                System.out.println(rev);
                str1 = kb.readLine();
               
                ps.println(str1);
            }
            ps.close();
            br.close();
            kb.close();
            ss.close();
            s.close();
            System.exit(0);
        }
    }
}
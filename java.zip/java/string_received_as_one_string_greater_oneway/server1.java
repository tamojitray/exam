import java.io.*;
import java.net.*;

public class server1 {
    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(6666);
            Socket s = ss.accept();
            DataInputStream dis = new DataInputStream(s.getInputStream());
            String str = (String) dis.readUTF();
            char[] arr = new char[str.length()];
            for (int i = 0; i < str.length(); i++) {
                char a = str.charAt(i);
                int ascii = (int) a;
                ascii++;
                char c = (char) ascii;
                arr[i] = c;
            }
            for (char x : arr) {
                System.out.print(x);
            }
            ss.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}